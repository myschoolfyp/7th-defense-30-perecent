import { NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import bcrypt from 'bcryptjs';
import Admin from '@/models/Admin';
import Teacher from '@/models/Teacher';

export async function POST(req: Request) {
  await dbConnect(); // Connect to MongoDB

  try {
    // Parse the request body
    const {
      firstName,
      lastName,
      email,
      password,
      userType,
      contactNumber,
      employeeCode,
      adminCode,
      profilePicture,
    } = await req.json();

    // Log the received data
    console.log("Received data:", {
      firstName,
      lastName,
      email,
      password,
      userType,
      contactNumber,
      employeeCode,
      adminCode,
      profilePicture,
    });

    // Define the mapping of user types to models
    const userModels: { [key: string]: any } = {
      Admin,
      Teacher,
    };
    const UserModel = userModels[userType];

    // Check if the user type is valid
    if (!UserModel) {
      console.error("Invalid user type:", userType);
      return NextResponse.json(
        { success: false, message: 'Invalid user type' },
        { status: 400 }
      );
    }

    // Check if the email already exists in the database
    const existingUser = await UserModel.findOne({ email });
    if (existingUser) {
      console.error("User already exists with email:", email);
      return NextResponse.json(
        { success: false, message: 'User already exists' },
        { status: 400 }
      );
    }

    // Hash the password before saving
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user object with profile picture
    const user = new UserModel({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      contactNumber,
      employeeCode,
      adminCode,
      profilePicture, // Store the profile picture (base64 string)
    });

    // Log the user object before saving
    console.log("User object to be saved:", user);

    // Save the user to the database
    await user.save();

    // Log the success message
    console.log("User saved successfully:", user);

    // Respond with a success message
    return NextResponse.json({
      success: true,
      message: 'User registered successfully',
    });
  } catch (error) {
    console.error("Error registering user:", error);
    return NextResponse.json(
      { success: false, message: 'Error registering user' },
      { status: 500 }
    );
  }
}
