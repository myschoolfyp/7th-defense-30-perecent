import { NextResponse } from "next/server";
import { MongoClient } from "mongodb";
import bcrypt from "bcryptjs";

const mongoUri = "mongodb://localhost:27017/myschool";
const client = new MongoClient(mongoUri);


export async function POST(request: Request) {
    try {
      const { email, password, userType } = await request.json();
  
      if (!email || !password || !userType) {
        return NextResponse.json(
          { message: "Missing email, password, or userType" },
          { status: 400 }
        );
      }
  
      await client.connect();
      const db = client.db();
      const collectionName = userType === "Admin" ? "admins" : "teachers";
      const user = await db.collection(collectionName).findOne({ email });
  
      if (!user) {
        return NextResponse.json({ message: "User not found" }, { status: 404 });
      }
  
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        return NextResponse.json({ message: "Invalid password" }, { status: 401 });
      }
  
      // Include adminCode or employeeCode based on userType
      const userCode = userType === "Admin" ? user.adminCode : user.employeeCode;
  
      return NextResponse.json({
        message: "User authenticated",
        user: {
          id: userCode, // Use adminCode or employeeCode as the ID
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          password, // Return plaintext password for editing
          contactNumber: user.contactNumber,
        },
      });
    } catch (error) {
      console.error("Error in POST:", error);
      return NextResponse.json({ message: "Internal server error" }, { status: 500 });
    } finally {
      await client.close();
    }
  }
  

  export async function PUT(request: Request) {
    try {
        const {
            identifier, // adminCode or employeeCode
            email,
            userType,
            firstName,
            lastName,
            password,
            contactNumber,
          } = await request.json();
          
          if (!identifier || !email || !userType) {
            return NextResponse.json(
              { message: "Missing required fields" },
              { status: 400 }
            );
          }
          
  
      await client.connect();
      const db = client.db();
      const collectionName = userType === "Admin" ? "admins" : "teachers";
  
      const updatedData: Partial<any> = {
        firstName,
        lastName,
        contactNumber,
      };
  
      if (password) {
        updatedData.password = await bcrypt.hash(password, 10);
      }
  
      // Use adminCode or employeeCode as the identifier
      const result = await db.collection(collectionName).updateOne(
        { [userType === "Admin" ? "adminCode" : "employeeCode"]: identifier },
        { $set: updatedData }
      );
      
      if (result.matchedCount === 0) {
        return NextResponse.json(
          { message: "No matching user found for update" },
          { status: 404 }
        );
      }
  
      if (result.modifiedCount === 0) {
        return NextResponse.json(
          { message: "No changes were made" },
          { status: 200 }
        );
      }
  
      return NextResponse.json({ message: "User updated successfully" });
    } catch (error) {
      console.error("Error in PUT:", error);
      return NextResponse.json({ message: "Internal server error" }, { status: 500 });
    } finally {
      await client.close();
    }
  }
  
